package com.cg.rms.service;

import com.cg.rms.bean.CandidatePersonal;
import com.cg.rms.bean.CandidateQualifications;

public interface IRmsService {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
	 public  CandidateQualifications   addCandidateQualification(CandidateQualifications cqualification);

}
