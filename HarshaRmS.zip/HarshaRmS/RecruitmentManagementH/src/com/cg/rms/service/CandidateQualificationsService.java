package com.cg.rms.service;

import java.util.List;

import com.cg.rms.dto.CandidateQualifications;
import com.cg.rms.exceptions.CandidateQualificationsException;

public interface CandidateQualificationsService {
	public String addCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException;
	List<CandidateQualifications> getAllQualifications() throws CandidateQualificationsException;
	public boolean updateCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException;


}
