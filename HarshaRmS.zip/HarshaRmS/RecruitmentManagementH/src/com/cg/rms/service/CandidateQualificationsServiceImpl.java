package com.cg.rms.service;


import java.util.List;

import com.cg.rms.dao.CandidateQualificationsDAO;
import com.cg.rms.dao.CandidateQualificationsDAOImpl;
import com.cg.rms.dto.CandidateQualifications;
import com.cg.rms.exceptions.CandidateQualificationsException;

public class CandidateQualificationsServiceImpl implements CandidateQualificationsService {
	private CandidateQualificationsDAO cdao= new CandidateQualificationsDAOImpl();
	@Override
	public String addCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException
	{
		// TODO Auto-generated method stub
		return cdao.addCandidateQualifications(cqualifications);
	}

	@Override
	public boolean updateCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException{
		// TODO Auto-generated method stub
		return cdao.updateCandidateQualifications(cqualifications);
	}

	@Override
	public List<CandidateQualifications> getAllQualifications() throws CandidateQualificationsException{
		
		return cdao.getAllQualifications();
	}

}
