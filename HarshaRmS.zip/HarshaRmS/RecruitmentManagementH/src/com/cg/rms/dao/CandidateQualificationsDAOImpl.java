package com.cg.rms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rms.dto.CandidateQualifications;
import com.cg.rms.exceptions.CandidateQualificationsException;



public class CandidateQualificationsDAOImpl implements CandidateQualificationsDAO {

	Connection conn;
	
	private String generateQualificationId() throws CandidateQualificationsException{
		
		conn = DBUtil.getConnection();
		String sql = "SELECT seq_qualification_id.NEXTVAL FROM DUAL";
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getString(1);
		} catch (SQLException e) {
			
			throw new CandidateQualificationsException("problem in generating course Id"+e.getMessage());
			//e.printStackTrace();
		}
		
	
	}
	
	@Override
	public String addCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException {
	String sql = "INSERT INTO Candidate_Qualifications values(?,?,?,?,?,?,?,?)";
	cqualifications.setQualification_id(generateQualificationId());
	conn = DBUtil.getConnection();
	PreparedStatement pst;
	try {
		pst = conn.prepareStatement(sql);
		pst.setString(1, cqualifications.getQualification_id());
		pst.setString(2, cqualifications.getQualification_name());
		pst.setString(3, cqualifications.getSpecialization_area());
		pst.setString(4,cqualifications.getCollege_name());
		pst.setString(5,cqualifications.getUniversity_name());
		pst.setString(6,cqualifications.getYear_of_passing());
		pst.setFloat(7,cqualifications.getPercentage());
		pst.setString(8,cqualifications.getCandidate_id());
		pst.executeUpdate();
		} catch (SQLException e) {
		throw new  CandidateQualificationsException("problem in insering the details"+e.getMessage());
		//e.printStackTrace();
	}
	
		
		return cqualifications.getQualification_id();
	}

	@Override
	public List<CandidateQualifications> getAllQualifications() throws  CandidateQualificationsException{
		String sql = "SELECT qualification_id,qualification_name, Specialization_area,college_name,university_name,year_of_passing,percentage,candidate_id FROM Candidate_Qualifications";
		ArrayList<CandidateQualifications> clist = new ArrayList();
		conn = DBUtil.getConnection();
		
			Statement st;
			try {
				st = conn.createStatement();
				ResultSet rst = st.executeQuery(sql);
				while(rst.next()) {
					CandidateQualifications	  c = new CandidateQualifications();
					c.setQualification_id(rst.getString("Qualification_id"));
					c.setQualification_name(rst.getString("Qualification_name"));
					c.setSpecialization_area(rst.getString("Specialization_area"));
					c.setCollege_name(rst.getString("College_name"));
					c.setUniversity_name(rst.getString("University_name"));
					c.setYear_of_passing(rst.getString("Year_of_passing"));
					c.setPercentage(rst.getFloat("Percentage"));
					c.setCandidate_id(rst.getString("Candidate_id"));
					clist.add(c);
				}
			} catch (SQLException e) {
				
				throw new CandidateQualificationsException("problem in fetching the deatails"+e.getMessage());
				//e.printStackTrace();
			}
			return clist;
			
			}
			
			
@Override
	public boolean updateCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter qualification ID");
	String	id = sc.next();
	String sql = "UPDATE Candidate_Qualifications SET qualification_name =?, specialization_area=?, college_name=?, university_name=?, year_of_passing=?, percentage=? where qualification_id=?"; 
		conn = DBUtil.getConnection();
		PreparedStatement pst;
		System.out.println("Enter the Details");
		System.out.println("Enter Qualification name");
		String nm = sc.next();
		System.out.println("enter Specialization area");
		String sa = sc.next();
		System.out.println("enter College name");
		String cn=sc.next();
		System.out.println("enter University name");
		String un=sc.next();
		System.out.println("enter Year of passing");
		String yop=sc.next();
		System.out.println("Enter your Percentage");
		String percentage=sc.next();
		
		
		try {
			pst = conn.prepareStatement(sql);
			
			pst.setString(1, nm);
			pst.setString(2, sa);
			pst.setString(3, cn);
			pst.setString(4, un);
			pst.setString(5, yop);
			pst.setString(6, percentage);
			pst.setString(7, id);
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new CandidateQualificationsException("problem in updating the details"+e.getMessage());
			//e.printStackTrace();
		}
		return true;
		
			
	
		}


	/*@Override
	public boolean deleteCourse(long course_id) throws CourseException {
		String sql = "delete from cource where course_id=?";
		conn = DBUtil.getConnection();
		PreparedStatement pst = null;
		try {
			pst = conn.prepareStatement(sql);
			pst.setLong(1, course_id);
			pst.executeUpdate();
		} catch (SQLException e) {
			
			throw new CourseException("problem in deleting the deatails"+e.getMessage());
		}
		
		
		return true;
	}*/

}
